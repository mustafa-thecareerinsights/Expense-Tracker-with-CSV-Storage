# Expense Tracker with CSV Storage

## Project Objective
This Python project is an expense management application that stores all expense records permanently in a CSV file.

## Features
- Add and save expenses to a CSV file
- View all expenses
- Filter expenses by date
- Filter expenses by month
- Calculate total expenses
- Generate expense summary report by category
- Uses exception handling and input validation

## Fields Used
- Expense ID
- Title
- Amount
- Date
- Category

## Files Included
- `expense_tracker.py` - Main Python source code
- `expenses.csv` - Created automatically when the program runs
- `README.md` - Project documentation

## How to Run
1. Install Python on your computer.
2. Open the project folder.
3. Open terminal or command prompt in the folder.
4. Run this command:

```bash
python expense_tracker.py
```

## Date Format
Use this format when entering date:

```text
YYYY-MM-DD
```

Example:

```text
2026-06-11
```

## Sample Output

```text
========== Expense Tracker ==========
1. Add Expense
2. View All Expenses
3. Filter Expenses by Date
4. Filter Expenses by Month
5. Calculate Total Expenses
6. Generate Summary Report
7. Exit
Enter your choice: 1

Enter expense title: Lunch
Enter amount: 12.50
Enter date (YYYY-MM-DD): 2026-06-11
Enter category: Food
Expense added successfully!
```

```text
All Expenses:
----------------------------------------------------------------------
ID   Title               Amount    Date           Category
----------------------------------------------------------------------
1    Lunch               12.5      2026-06-11     Food
2    Bus Ticket          3.0       2026-06-11     Transport
```

```text
Total Expenses: $15.50
```

```text
Expense Summary Report by Category:
----------------------------------------
Food                : $12.50
Transport           : $3.00
```

## Exception Handling
The program handles:
- Invalid amount input
- Invalid date format
- Missing CSV file
- Empty title or category
- General file handling errors

## Submission
Submit the following:
1. Source Code file: `expense_tracker.py`
2. README file: `README.md`
3. Sample output screenshots
