# Expense Tracker with CSV Storage

## Project Title
Expense Tracker with CSV Storage

## Objective
This Python project is an expense management application that stores expense records in a CSV file.

## Features
- Add and save expenses to a CSV file
- View all expenses
- Filter expenses by date
- Filter expenses by month
- Calculate total expenses
- Generate category-wise expense summary report
- Proper file handling and exception handling
- Input validation for amount and date

## Fields Used
- Expense ID
- Title
- Amount
- Date
- Category

## How to Run
1. Install Python on your computer.
2. Download or clone this project.
3. Open terminal or command prompt inside the project folder.
4. Run this command:

```bash
python expense_tracker.py
```

## Date Format
Use this format when entering dates:

```text
YYYY-MM-DD
```

Example:

```text
2026-06-11
```

## Sample Output

```text
Expense Tracker with CSV Storage
1. Add Expense
2. View All Expenses
3. Filter Expenses by Date
4. Filter Expenses by Month
5. Calculate Total Expenses
6. Generate Summary Report
7. Exit
Enter your choice (1-7): 1
Enter expense title: Lunch
Enter amount: 15.50
Enter date (YYYY-MM-DD): 2026-06-11
Enter category: Food
Expense added successfully.
```

```text
Expense ID   Title                Amount     Date         Category
---------------------------------------------------------------------------
1            Lunch                $15.50     2026-06-11   Food
2            Bus Ticket           $3.25      2026-06-11   Transport
```

```text
Expense Summary Report
----------------------------------------
Food                : $15.50
Transport           : $3.25
----------------------------------------
Grand Total         : $18.75
```

## Files Included
- `expense_tracker.py` - Main Python source code
- `README.md` - Project documentation
- `expenses.csv` - CSV storage file with sample data
- `sample_output.txt` - Sample program result/output

## Notes
The program automatically creates the CSV file if it does not exist.
