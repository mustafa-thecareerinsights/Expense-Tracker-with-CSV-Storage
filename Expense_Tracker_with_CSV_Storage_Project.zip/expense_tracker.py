import csv
import os
from datetime import datetime
from collections import defaultdict

CSV_FILE = "expenses.csv"
FIELDS = ["Expense ID", "Title", "Amount", "Date", "Category"]

def initialize_file():
    """Create CSV file with headers if it does not exist."""
    if not os.path.exists(CSV_FILE):
        with open(CSV_FILE, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(FIELDS)

def get_next_id():
    """Return next expense ID."""
    initialize_file()
    try:
        with open(CSV_FILE, mode="r", newline="", encoding="utf-8") as file:
            reader = list(csv.DictReader(file))
            if not reader:
                return 1
            return max(int(row["Expense ID"]) for row in reader) + 1
    except (FileNotFoundError, ValueError):
        return 1

def validate_date(date_text):
    """Validate date format YYYY-MM-DD."""
    try:
        datetime.strptime(date_text, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def add_expense():
    """Add a new expense to CSV file."""
    try:
        title = input("Enter expense title: ").strip()
        if not title:
            print("Title cannot be empty.")
            return

        amount = float(input("Enter amount: ").strip())
        if amount <= 0:
            print("Amount must be greater than 0.")
            return

        date = input("Enter date (YYYY-MM-DD): ").strip()
        if not validate_date(date):
            print("Invalid date format. Use YYYY-MM-DD.")
            return

        category = input("Enter category: ").strip()
        if not category:
            print("Category cannot be empty.")
            return

        expense_id = get_next_id()

        with open(CSV_FILE, mode="a", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow([expense_id, title, amount, date, category])

        print("Expense added successfully.")

    except ValueError:
        print("Invalid amount. Please enter a number.")
    except Exception as e:
        print(f"Error while adding expense: {e}")

def read_expenses():
    """Read all expenses from CSV file."""
    initialize_file()
    try:
        with open(CSV_FILE, mode="r", newline="", encoding="utf-8") as file:
            return list(csv.DictReader(file))
    except FileNotFoundError:
        print("Expense file not found.")
        return []
    except Exception as e:
        print(f"Error reading expenses: {e}")
        return []

def display_expenses(expenses):
    """Display expenses in table format."""
    if not expenses:
        print("No expenses found.")
        return

    print("\n{:<12} {:<20} {:<10} {:<12} {:<15}".format(
        "Expense ID", "Title", "Amount", "Date", "Category"
    ))
    print("-" * 75)

    for row in expenses:
        print("{:<12} {:<20} ${:<9.2f} {:<12} {:<15}".format(
            row["Expense ID"],
            row["Title"],
            float(row["Amount"]),
            row["Date"],
            row["Category"]
        ))

def view_all_expenses():
    """Show all expenses."""
    expenses = read_expenses()
    display_expenses(expenses)

def filter_by_date():
    """Filter expenses by exact date."""
    date = input("Enter date to filter (YYYY-MM-DD): ").strip()
    if not validate_date(date):
        print("Invalid date format. Use YYYY-MM-DD.")
        return

    expenses = read_expenses()
    filtered = [row for row in expenses if row["Date"] == date]
    display_expenses(filtered)

def filter_by_month():
    """Filter expenses by month YYYY-MM."""
    month = input("Enter month to filter (YYYY-MM): ").strip()
    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        print("Invalid month format. Use YYYY-MM.")
        return

    expenses = read_expenses()
    filtered = [row for row in expenses if row["Date"].startswith(month)]
    display_expenses(filtered)

def calculate_total():
    """Calculate total expenses."""
    expenses = read_expenses()
    try:
        total = sum(float(row["Amount"]) for row in expenses)
        print(f"Total Expenses: ${total:.2f}")
    except Exception as e:
        print(f"Error calculating total: {e}")

def summary_report():
    """Generate category-wise summary report."""
    expenses = read_expenses()
    if not expenses:
        print("No expenses found.")
        return

    category_totals = defaultdict(float)
    grand_total = 0.0

    for row in expenses:
        amount = float(row["Amount"])
        category_totals[row["Category"]] += amount
        grand_total += amount

    print("\nExpense Summary Report")
    print("-" * 40)
    for category, total in category_totals.items():
        print(f"{category:<20}: ${total:.2f}")
    print("-" * 40)
    print(f"{'Grand Total':<20}: ${grand_total:.2f}")

def menu():
    """Main menu."""
    initialize_file()

    while True:
        print("\nExpense Tracker with CSV Storage")
        print("1. Add Expense")
        print("2. View All Expenses")
        print("3. Filter Expenses by Date")
        print("4. Filter Expenses by Month")
        print("5. Calculate Total Expenses")
        print("6. Generate Summary Report")
        print("7. Exit")

        choice = input("Enter your choice (1-7): ").strip()

        if choice == "1":
            add_expense()
        elif choice == "2":
            view_all_expenses()
        elif choice == "3":
            filter_by_date()
        elif choice == "4":
            filter_by_month()
        elif choice == "5":
            calculate_total()
        elif choice == "6":
            summary_report()
        elif choice == "7":
            print("Thank you for using Expense Tracker.")
            break
        else:
            print("Invalid choice. Please select 1 to 7.")

if __name__ == "__main__":
    menu()
